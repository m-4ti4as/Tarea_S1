package com.example.restauranteapp.modelo

data class ItemMenu(
    val nombre: String,
    val precio: Int
)

package com.example.restauranteapp.modelo

class CuentaMesa(
    val mesa: Int
) {
    private val _items = mutableListOf<ItemMesa>()
    val items: List<ItemMesa> get() = _items.toList()

    var aceptaPropina: Boolean = true

    fun agregarItem(itemMesa: ItemMesa) {
        _items.add(itemMesa)
    }

    fun agregarItem(itemMenu: ItemMenu, cantidad: Int) {
        val nuevoItemMesa = ItemMesa(itemMenu, cantidad)
        _items.add(nuevoItemMesa)
    }

    fun calcularTotalSinPropina(): Int {
        var total = 0
        for (item in _items) {
            total += item.calcularSubtotal()
        }
        return total
    }

    fun calcularPropina(): Int {
        if (!aceptaPropina) {
            return 0
        }
        return (calcularTotalSinPropina() * 0.1).toInt()
    }

    fun calcularTotalConPropina(): Int {
        return calcularTotalSinPropina() + calcularPropina()
    }
}

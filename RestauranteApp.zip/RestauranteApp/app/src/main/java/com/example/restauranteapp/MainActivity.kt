package com.example.restauranteapp

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.restauranteapp.modelo.CuentaMesa
import com.example.restauranteapp.modelo.ItemMenu
import com.example.restauranteapp.modelo.ItemMesa
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var etCantidadPastel: EditText
    private lateinit var tvSubtotalPastel: TextView
    private lateinit var etCantidadCazuela: EditText
    private lateinit var tvSubtotalCazuela: TextView
    private lateinit var swPropina: Switch
    private lateinit var tvTotalComida: TextView
    private lateinit var tvTotalPropina: TextView
    private lateinit var tvTotalFinal: TextView

    private val pastelChoclo = ItemMenu("Pastel de Choclo", 12000)
    private val cazuela = ItemMenu("Cazuela", 10000)
    private val itemPastel = ItemMesa(pastelChoclo, 0)
    private val itemCazuela = ItemMesa(cazuela, 0)
    private val cuentaMesa = CuentaMesa(1)

    private val formatoMoneda = NumberFormat.getCurrencyInstance(Locale("es", "CL"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etCantidadPastel = findViewById(R.id.etCantidadPastel)
        tvSubtotalPastel = findViewById(R.id.tvSubtotalPastel)
        etCantidadCazuela = findViewById(R.id.etCantidadCazuela)
        tvSubtotalCazuela = findViewById(R.id.tvSubtotalCazuela)
        swPropina = findViewById(R.id.swPropina)
        tvTotalComida = findViewById(R.id.tvTotalComida)
        tvTotalPropina = findViewById(R.id.tvTotalPropina)
        tvTotalFinal = findViewById(R.id.tvTotalFinal)

        // Agregar items a la cuenta de la mesa
        cuentaMesa.agregarItem(itemPastel)
        cuentaMesa.agregarItem(itemCazuela)

        configurarListeners()
        actualizarTotales()
    }

    private fun configurarListeners() {
        // Cantidad del Pastel de Choclo
        etCantidadPastel.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val cantidad = s.toString().toIntOrNull() ?: 0
                itemPastel.cantidad = cantidad
                actualizarTotales() // Recalcular y refrescar la pantalla
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Cantidad de la Cazuela
        etCantidadCazuela.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val cantidad = s.toString().toIntOrNull() ?: 0
                itemCazuela.cantidad = cantidad
                actualizarTotales()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        // Switch de la propina
        swPropina.setOnCheckedChangeListener { _, isChecked ->
            cuentaMesa.aceptaPropina = isChecked
            actualizarTotales()
        }
    }

    private fun actualizarTotales() {
        // Actualizar subtotales de cada plato
        tvSubtotalPastel.text = formatoMoneda.format(itemPastel.calcularSubtotal())
        tvSubtotalCazuela.text = formatoMoneda.format(itemCazuela.calcularSubtotal())

        // Calcular totales generales
        val totalSinPropina = cuentaMesa.calcularTotalSinPropina()
        val propina = cuentaMesa.calcularPropina()
        val totalConPropina = cuentaMesa.calcularTotalConPropina()

        tvTotalComida.text = formatoMoneda.format(totalSinPropina)
        tvTotalPropina.text = formatoMoneda.format(propina)
        tvTotalFinal.text = formatoMoneda.format(totalConPropina)
    }
}
